import React from 'react';
import { Link, useLocation } from 'wouter';
import { 
  Home, 
  TerminalSquare, 
  Users, 
  Rocket, 
  BookOpen, 
  Globe, 
  Settings,
  LogOut,
  Sparkles
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { icon: Home, label: 'Home', href: '/home' },
    { icon: TerminalSquare, label: 'My Repls', href: '/repls' },
    { icon: Sparkles, label: 'Agent', href: '/agent' },
    { icon: Users, label: 'Teams', href: '/home' },
    { icon: Rocket, label: 'Deployments', href: '/home' },
    { icon: BookOpen, label: 'Learn', href: '/home' },
    { icon: Globe, label: 'Community', href: '/home' },
  ];

  return (
    <aside className="w-64 bg-sidebar border-r border-border flex flex-col h-screen sticky top-0">
      <div className="p-4 flex items-center gap-3">
        <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center text-primary-foreground font-mono font-bold text-lg">
          R
        </div>
        <span className="font-semibold text-lg tracking-tight">Replit</span>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link 
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                isActive 
                  ? 'bg-secondary text-foreground' 
                  : 'text-muted-foreground hover:bg-secondary/50 hover:text-foreground'
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border space-y-4">
        <Link 
          href="/settings"
          className="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:bg-secondary/50 hover:text-foreground transition-colors"
        >
          <Settings className="w-4 h-4" />
          Settings
        </Link>
        
        <div className="flex items-center gap-3 px-3 py-2">
          <Avatar className="w-8 h-8 border border-border">
            <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" />
            <AvatarFallback>U</AvatarFallback>
          </Avatar>
          <div className="flex flex-col flex-1 min-w-0">
            <span className="text-sm font-medium truncate">username</span>
            <span className="text-xs text-muted-foreground truncate">Free Plan</span>
          </div>
          <Link href="/">
            <LogOut className="w-4 h-4 text-muted-foreground hover:text-foreground cursor-pointer" />
          </Link>
        </div>
      </div>
    </aside>
  );
}
