import React from 'react';
import { MoreHorizontal, Star } from 'lucide-react';
import { 
  SiPython, 
  SiJavascript, 
  SiHtml5, 
  SiNodedotjs, 
  SiReact, 
  SiCplusplus 
} from 'react-icons/si';

interface ReplCardProps {
  name: string;
  language: string;
  updatedAt: string;
  isStarred?: boolean;
}

const getLanguageIcon = (lang: string) => {
  switch (lang.toLowerCase()) {
    case 'python':
      return <div className="w-8 h-8 rounded bg-blue-500/10 flex items-center justify-center text-blue-500"><SiPython className="w-5 h-5" /></div>;
    case 'javascript':
      return <div className="w-8 h-8 rounded bg-yellow-500/10 flex items-center justify-center text-yellow-500"><SiJavascript className="w-5 h-5" /></div>;
    case 'html/css/js':
      return <div className="w-8 h-8 rounded bg-orange-500/10 flex items-center justify-center text-orange-500"><SiHtml5 className="w-5 h-5" /></div>;
    case 'node.js':
      return <div className="w-8 h-8 rounded bg-green-500/10 flex items-center justify-center text-green-500"><SiNodedotjs className="w-5 h-5" /></div>;
    case 'react':
      return <div className="w-8 h-8 rounded bg-cyan-500/10 flex items-center justify-center text-cyan-500"><SiReact className="w-5 h-5" /></div>;
    case 'c++':
      return <div className="w-8 h-8 rounded bg-indigo-500/10 flex items-center justify-center text-indigo-500"><SiCplusplus className="w-5 h-5" /></div>;
    default:
      return <div className="w-8 h-8 rounded bg-gray-500/10 flex items-center justify-center text-gray-500"><div className="w-5 h-5 font-mono font-bold text-xs flex items-center justify-center">{"</>"}</div></div>;
  }
};

export default function ReplCard({ name, language, updatedAt, isStarred = false }: ReplCardProps) {
  return (
    <div className="group flex flex-col p-4 bg-card hover:bg-secondary/40 border border-border rounded-xl transition-all cursor-pointer">
      <div className="flex items-start justify-between mb-4">
        {getLanguageIcon(language)}
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-secondary rounded-md">
            <Star className={`w-4 h-4 ${isStarred ? 'fill-yellow-500 text-yellow-500' : ''}`} />
          </button>
          <button className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-secondary rounded-md">
            <MoreHorizontal className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      <h3 className="font-medium text-foreground truncate mb-1">{name}</h3>
      <div className="flex items-center text-xs text-muted-foreground mt-auto">
        <span className="truncate">{language}</span>
        <span className="mx-1.5">•</span>
        <span>{updatedAt}</span>
      </div>
    </div>
  );
}
