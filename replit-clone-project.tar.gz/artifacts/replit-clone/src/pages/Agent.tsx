import React from 'react';
import Sidebar from '@/components/Sidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sparkles, Send, ArrowUp, Code2, Terminal, Globe } from 'lucide-react';

export default function Agent() {
  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar />
      
      <main className="flex-1 flex flex-col h-screen overflow-hidden bg-background relative">
        <div className="flex-1 overflow-y-auto pb-32">
          <div className="max-w-3xl mx-auto w-full pt-20 px-8 flex flex-col items-center text-center">
            
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-6">
              <Sparkles className="w-8 h-8 text-primary" />
            </div>
            
            <h1 className="text-4xl font-bold tracking-tight mb-4">What do you want to build?</h1>
            <p className="text-lg text-muted-foreground mb-12 max-w-xl">
              Describe an app, API, or script, and Replit Agent will write the code, configure the environment, and deploy it for you.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 w-full max-w-2xl mb-8">
              {[
                { icon: Globe, text: "Build a personal portfolio site" },
                { icon: Terminal, text: "Create a Discord bot" },
                { icon: Code2, text: "Make a React to-do app" },
                { icon: Sparkles, text: "Build an AI chat interface" },
                { icon: Globe, text: "Create a REST API with Express" },
                { icon: Terminal, text: "Write a python web scraper" }
              ].map((prompt, i) => (
                <button 
                  key={i}
                  className="flex items-center gap-3 p-3 bg-secondary/30 hover:bg-secondary/80 border border-border rounded-xl text-sm text-left transition-colors"
                >
                  <prompt.icon className="w-4 h-4 text-muted-foreground shrink-0" />
                  <span className="text-muted-foreground line-clamp-2">{prompt.text}</span>
                </button>
              ))}
            </div>
            
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background via-background to-transparent pt-10 pb-8 px-8 border-t border-border/0">
          <div className="max-w-3xl mx-auto relative">
            <div className="absolute -top-12 left-0 right-0 flex justify-center pointer-events-none">
              <div className="bg-primary/10 text-primary text-xs font-mono px-3 py-1 rounded-full border border-primary/20">
                Agent is ready
              </div>
            </div>
            <div className="relative flex items-end gap-2 bg-card border border-border rounded-2xl p-2 shadow-sm focus-within:ring-1 focus-within:ring-primary/50 transition-shadow">
              <div className="flex-1">
                <textarea 
                  placeholder="Describe your idea..." 
                  className="w-full bg-transparent border-0 focus:ring-0 resize-none max-h-32 min-h-[44px] p-2 text-sm placeholder:text-muted-foreground font-sans focus:outline-none"
                  rows={1}
                />
              </div>
              <Button size="icon" className="shrink-0 h-10 w-10 rounded-xl mb-0.5">
                <ArrowUp className="w-5 h-5" />
              </Button>
            </div>
            <div className="text-center mt-3">
              <span className="text-xs text-muted-foreground">Replit Agent can make mistakes. Consider verifying important information.</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
