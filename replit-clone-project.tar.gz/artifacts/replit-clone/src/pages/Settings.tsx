import React from 'react';
import Sidebar from '@/components/Sidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { SiGithub, SiGoogle } from 'react-icons/si';

export default function Settings() {
  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar />
      
      <main className="flex-1 flex flex-col h-screen overflow-y-auto">
        <div className="p-8 max-w-4xl mx-auto w-full">
          <h1 className="text-2xl font-bold tracking-tight mb-8">Settings</h1>

          <Tabs defaultValue="account" className="w-full">
            <TabsList className="mb-8 bg-secondary border border-border w-full justify-start overflow-x-auto rounded-lg h-auto p-1">
              <TabsTrigger value="account" className="data-[state=active]:bg-background">Account</TabsTrigger>
              <TabsTrigger value="profile" className="data-[state=active]:bg-background">Profile</TabsTrigger>
              <TabsTrigger value="ssh" className="data-[state=active]:bg-background">SSH Keys</TabsTrigger>
              <TabsTrigger value="connected" className="data-[state=active]:bg-background">Connected Services</TabsTrigger>
              <TabsTrigger value="privacy" className="data-[state=active]:bg-background">Privacy</TabsTrigger>
              <TabsTrigger value="notifications" className="data-[state=active]:bg-background">Notifications</TabsTrigger>
            </TabsList>

            <TabsContent value="account" className="space-y-6">
              <div className="bg-card border border-border rounded-xl p-6">
                <h3 className="text-lg font-medium mb-4">Account Information</h3>
                <div className="space-y-4 max-w-md">
                  <div className="space-y-2">
                    <Label>Username</Label>
                    <Input defaultValue="username" className="bg-background" />
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input defaultValue="user@example.com" type="email" className="bg-background" />
                  </div>
                  <Button>Save Changes</Button>
                </div>
              </div>

              <div className="bg-card border border-border rounded-xl p-6">
                <h3 className="text-lg font-medium mb-4">Change Password</h3>
                <div className="space-y-4 max-w-md">
                  <div className="space-y-2">
                    <Label>Current Password</Label>
                    <Input type="password" className="bg-background" />
                  </div>
                  <div className="space-y-2">
                    <Label>New Password</Label>
                    <Input type="password" className="bg-background" />
                  </div>
                  <div className="space-y-2">
                    <Label>Confirm New Password</Label>
                    <Input type="password" className="bg-background" />
                  </div>
                  <Button variant="secondary">Update Password</Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="profile" className="space-y-6">
              <div className="bg-card border border-border rounded-xl p-6">
                <h3 className="text-lg font-medium mb-4">Public Profile</h3>
                <div className="flex flex-col sm:flex-row gap-8">
                  <div className="flex flex-col items-center gap-4">
                    <Avatar className="w-24 h-24 border-2 border-border">
                      <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" />
                      <AvatarFallback>U</AvatarFallback>
                    </Avatar>
                    <Button variant="outline" size="sm">Change Avatar</Button>
                  </div>
                  
                  <div className="flex-1 space-y-4 max-w-md">
                    <div className="space-y-2">
                      <Label>Display Name</Label>
                      <Input defaultValue="User Name" className="bg-background" />
                    </div>
                    <div className="space-y-2">
                      <Label>Bio</Label>
                      <Textarea placeholder="Tell us about yourself" className="bg-background min-h-[100px]" />
                    </div>
                    <div className="space-y-2">
                      <Label>Website</Label>
                      <Input placeholder="https://" className="bg-background" />
                    </div>
                    <Button>Save Profile</Button>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="connected" className="space-y-6">
              <div className="bg-card border border-border rounded-xl p-6">
                <h3 className="text-lg font-medium mb-2">Connected Services</h3>
                <p className="text-sm text-muted-foreground mb-6">Connect your accounts to enable single sign-on and import repositories.</p>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-background">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                        <SiGithub className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-medium">GitHub</h4>
                        <p className="text-sm text-muted-foreground">Not connected</p>
                      </div>
                    </div>
                    <Button variant="outline">Connect</Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-background">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                        <SiGoogle className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-medium">Google</h4>
                        <p className="text-sm text-muted-foreground text-green-500">Connected as user@example.com</p>
                      </div>
                    </div>
                    <Button variant="outline" className="text-destructive hover:text-destructive">Disconnect</Button>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            {/* Empty states for other tabs to keep it clean */}
            <TabsContent value="ssh" className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-lg font-medium mb-4">SSH Keys</h3>
              <p className="text-muted-foreground">Manage your SSH keys for secure access.</p>
            </TabsContent>
            
            <TabsContent value="privacy" className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-lg font-medium mb-4">Privacy</h3>
              <p className="text-muted-foreground">Manage your privacy settings.</p>
            </TabsContent>
            
            <TabsContent value="notifications" className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-lg font-medium mb-4">Notifications</h3>
              <p className="text-muted-foreground">Manage how we contact you.</p>
            </TabsContent>

          </Tabs>

        </div>
      </main>
    </div>
  );
}
