import React from 'react';
import { Link } from 'wouter';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { SiGithub, SiGoogle } from 'react-icons/si';

export default function Register() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="flex flex-col items-center text-center space-y-2">
          <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-mono font-bold text-2xl mb-4">
            R
          </div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Create your Replit account</h1>
          <p className="text-sm text-muted-foreground">
            Already have an account? <Link href="/" className="text-primary hover:underline">Log in</Link>
          </p>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <form className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input id="username" type="text" placeholder="coder123" className="bg-background" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="name@example.com" className="bg-background" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" className="bg-background" />
            </div>

            <Button type="button" onClick={() => window.location.href='/home'} className="w-full font-medium">
              Create account
            </Button>
          </form>

          <div className="mt-6 flex items-center justify-between">
            <span className="w-1/5 border-b border-border"></span>
            <span className="text-xs text-muted-foreground uppercase">or continue with</span>
            <span className="w-1/5 border-b border-border"></span>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <Button variant="outline" className="w-full flex items-center gap-2 bg-background hover:bg-secondary">
              <SiGoogle className="w-4 h-4" />
              Google
            </Button>
            <Button variant="outline" className="w-full flex items-center gap-2 bg-background hover:bg-secondary">
              <SiGithub className="w-4 h-4" />
              GitHub
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
