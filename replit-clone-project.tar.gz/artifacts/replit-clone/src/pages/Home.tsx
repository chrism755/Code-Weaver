import React from 'react';
import Sidebar from '@/components/Sidebar';
import ReplCard from '@/components/ReplCard';
import { Button } from '@/components/ui/button';
import { Plus, Search, ChevronRight } from 'lucide-react';
import { SiPython, SiReact, SiJavascript, SiHtml5 } from 'react-icons/si';

const recentRepls = [
  { id: 1, name: 'Discord Bot', language: 'Node.js', updatedAt: '2h ago' },
  { id: 2, name: 'Portfolio Site', language: 'React', updatedAt: '5h ago' },
  { id: 3, name: 'Data Scraper', language: 'Python', updatedAt: '1d ago' },
  { id: 4, name: 'Landing Page', language: 'HTML/CSS/JS', updatedAt: '2d ago' },
];

export default function Home() {
  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar />
      
      <main className="flex-1 flex flex-col h-screen overflow-y-auto">
        <div className="p-8 max-w-5xl mx-auto w-full space-y-10">
          
          <section className="bg-card border border-border rounded-2xl p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
            <div className="relative z-10 max-w-lg">
              <h1 className="text-3xl font-bold mb-3 tracking-tight">Start building</h1>
              <p className="text-muted-foreground mb-6">Build software collaboratively from anywhere in the world, on any device, without spending a second on setup.</p>
              <div className="flex items-center gap-3">
                <Button className="gap-2 font-medium" size="lg">
                  <Plus className="w-4 h-4" />
                  Create Repl
                </Button>
                <Button variant="outline" className="gap-2 font-medium" size="lg">
                  Import from GitHub
                </Button>
              </div>
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold tracking-tight">Recent Repls</h2>
              <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90">
                View all <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {recentRepls.map(repl => (
                <ReplCard key={repl.id} {...repl} />
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold tracking-tight mb-4">Templates</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { name: 'Python', icon: SiPython, color: 'text-blue-500' },
                { name: 'React', icon: SiReact, color: 'text-cyan-500' },
                { name: 'Node.js', icon: SiJavascript, color: 'text-yellow-500' },
                { name: 'HTML, CSS, JS', icon: SiHtml5, color: 'text-orange-500' },
              ].map((template, i) => (
                <div key={i} className="flex items-center gap-3 p-4 bg-card border border-border rounded-xl hover:bg-secondary/50 cursor-pointer transition-colors">
                  <template.icon className={`w-6 h-6 ${template.color}`} />
                  <span className="font-medium">{template.name}</span>
                </div>
              ))}
            </div>
          </section>

        </div>
      </main>
    </div>
  );
}
