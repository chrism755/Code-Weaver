import React, { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import ReplCard from '@/components/ReplCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Plus, Filter } from 'lucide-react';

const allRepls = [
  { id: 1, name: 'Discord Bot', language: 'Node.js', updatedAt: '2h ago', starred: true },
  { id: 2, name: 'Portfolio Site', language: 'React', updatedAt: '5h ago', starred: false },
  { id: 3, name: 'Data Scraper', language: 'Python', updatedAt: '1d ago', starred: true },
  { id: 4, name: 'Landing Page', language: 'HTML/CSS/JS', updatedAt: '2d ago', starred: false },
  { id: 5, name: 'Algorithm Practice', language: 'C++', updatedAt: '3d ago', starred: false },
  { id: 6, name: 'Weather App', language: 'React', updatedAt: '1w ago', starred: false },
  { id: 7, name: 'Flask API', language: 'Python', updatedAt: '2w ago', starred: false },
  { id: 8, name: 'Express Server', language: 'Node.js', updatedAt: '1m ago', starred: true },
];

export default function Repls() {
  const [filter, setFilter] = useState('All');
  
  const filteredRepls = allRepls.filter(r => {
    if (filter === 'Starred') return r.starred;
    return true;
  });

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar />
      
      <main className="flex-1 flex flex-col h-screen overflow-y-auto">
        <div className="p-8 max-w-6xl mx-auto w-full">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <h1 className="text-2xl font-bold tracking-tight">My Repls</h1>
            <Button className="gap-2 font-medium">
              <Plus className="w-4 h-4" />
              Create Repl
            </Button>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 mb-6">
            <div className="relative w-full sm:w-96">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input 
                placeholder="Search repls..." 
                className="pl-9 bg-card border-border h-10"
              />
            </div>
            
            <div className="flex bg-secondary p-1 rounded-lg">
              {['All', 'Starred', 'Recent'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setFilter(tab)}
                  className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${
                    filter === tab 
                      ? 'bg-background text-foreground shadow-sm' 
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredRepls.map(repl => (
              <ReplCard key={repl.id} {...repl} isStarred={repl.starred} />
            ))}
          </div>

          {filteredRepls.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-border rounded-2xl bg-card/50">
              <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-4">
                <Search className="w-6 h-6 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium mb-1">No repls found</h3>
              <p className="text-sm text-muted-foreground">We couldn't find any repls matching your criteria.</p>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
